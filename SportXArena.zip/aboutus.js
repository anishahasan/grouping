// script.js
document.addEventListener("DOMContentLoaded", () => {
    const animatedElements = document.querySelectorAll(".animate");
  
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("active");
          }
        });
      },
      {
        threshold: 0.2, // Trigger when 20% of the element is visible
      }
    );
  
    animatedElements.forEach((element) => observer.observe(element));
  });
  