// Open the popup with the selected image
function openPopup(image) {
    const popup = document.getElementById('popup');
    const popupImg = document.getElementById('popup-img');
    
    popup.style.display = 'flex';
    popupImg.src = image.src;
  }
  
  // Close the popup
  function closePopup() {
    const popup = document.getElementById('popup');
    popup.style.display = 'none';
  }
  